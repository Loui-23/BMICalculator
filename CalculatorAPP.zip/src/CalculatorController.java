import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;

public class CalculatorController {
    @FXML
    private TextField number1;

    @FXML
    private TextField number2;

    @FXML
    private TextField result;

    @FXML
    protected void handleAdd(ActionEvent event) {
        double num1 = Double.parseDouble(number1.getText());
        double num2 = Double.parseDouble(number2.getText());
        result.setText(String.valueOf(num1 + num2));
    }

    @FXML
    protected void handleSubtract(ActionEvent event) {
        double num1 = Double.parseDouble(number1.getText());
        double num2 = Double.parseDouble(number2.getText());
        result.setText(String.valueOf(num1 - num2));
    }

    @FXML
    protected void handleMultiply(ActionEvent event) {
        double num1 = Double.parseDouble(number1.getText());
        double num2 = Double.parseDouble(number2.getText());
        result.setText(String.valueOf(num1 * num2));
    }

    @FXML
    protected void handleDivide(ActionEvent event) {
        double num1 = Double.parseDouble(number1.getText());
        double num2 = Double.parseDouble(number2.getText());
        result.setText(num2 != 0 ? String.valueOf(num1 / num2) : "Error");
    }

    @FXML
    protected void handleClear(ActionEvent event) {
        number1.setText("");
        number2.setText("");
        result.setText("");
    }

    @FXML
    protected void handleExit(ActionEvent event) {
        System.exit(0);
    }
}