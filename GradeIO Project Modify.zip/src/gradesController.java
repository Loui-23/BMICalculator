import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class gradesController {

    @FXML
    private TextField filenameTextField;
    
    @FXML
    private ComboBox<String> gradesComboBox;
    
    @FXML
    private Label gpaLabel;

    private final ArrayList<String> gradesList = new ArrayList<>();

    @FXML
    protected void handleReadGrades() {
        String filename = filenameTextField.getText();
        gradesList.clear();
        gradesComboBox.getItems().clear();
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                gradesList.add(line);
                gradesComboBox.getItems().add(line);
            }
        } catch (IOException e) {
            // Handle exception
            
        }
    }

    @FXML
    protected void handleCalcGPA() {
        String selectedGrade = gradesComboBox.getValue();
        if (selectedGrade != null) {
            String gpa = convertGradeToGPA(selectedGrade);
            gpaLabel.setText(gpa);
        }
    }

    private String convertGradeToGPA(String grade) {
        // Example conversion logic. This needs to be replaced with actual logic.
        return switch (grade) {
            case "A" -> "4.0";
            case "B" -> "3.0";
            case "C" -> "2.0";
            case "D" -> "1.0";
            case "F" -> "0.0";
            default -> "Invalid grade";
        };
    }

    @FXML
    protected void handleMinimize() {
        Stage stage = (Stage) gpaLabel.getScene().getWindow();
        stage.setIconified(true);
    }
}
