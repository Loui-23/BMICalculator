import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class bmi_calculatorController {

    @FXML
    private TextField heightField;

    @FXML
    private TextField weightField;

    @FXML
    private Label resultLabel;

    @FXML
    public void calculateBMI() {
        try {
            double height = Double.parseDouble(heightField.getText());
            double weight = Double.parseDouble(weightField.getText());

            double bmi = weight / (height * height);

            String result;
            if (bmi < 18.5) {
                result = "Underweight";
            } else if (bmi < 24.9) {
                result = "Normal weight";
            } else if (bmi < 29.9) {
                result = "Overweight";
            } else {
                result = "Obese";
            }

            resultLabel.setText("BMI: " + String.format("%.2f", bmi) + " - " + result);
        } catch (NumberFormatException e) {
            resultLabel.setText("Please enter valid numbers for height and weight.");
        }
    }
}