package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class BMICalculator extends Application {
	
	@Override 
	public void start(Stage primaryStage) throws Exception {
	
        Label label1 = new Label("Weight (kg):");
        TextField textField1 = new TextField();
    
        Label label2 = new Label("Height (m):");
        TextField textField2 = new TextField();
      
        Button button = new Button("Calculate BMI");

       
        GridPane gridPane = new GridPane();
     
        gridPane.add(label1, 0, 0); 
        gridPane.add(textField1, 1, 0); 
        gridPane.add(label2, 0, 1); 
        gridPane.add(textField2, 1, 1); 
        gridPane.add(button, 1, 2); 

       
        button.setOnAction(e -> {
           
            double weight = Double.parseDouble(textField1.getText());
            double height = Double.parseDouble(textField2.getText());
            
            BMICalculator bmiCalculator = new BMICalculator();
          
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("BMI");
            
            double BMI = bmiCalculator.getBMI();
         
            String BMIStr=String.format("%.2f", BMI);
         
           
            if (BMI < 18 || BMI > 35) {
              
                alert.setHeaderText("ATTENTION!");
            
                alert.setContentText("BMI is " + BMIStr + ", Patient is " +
                        bmiCalculator.getMessage() + " and should consult with a doctor.");
            } else {
                
                alert.setContentText("BMI is " + BMIStr + ", Patient is " +
                        bmiCalculator.getMessage());
            }
         
            alert.showAndWait();
        });

      
        gridPane.setPadding(new Insets(20));
        gridPane.setVgap(10);
        gridPane.setHgap(10);


        
        Scene scene = new Scene(gridPane);
        Stage stage = null;
		stage.setScene(scene);
        stage.show();
    }

	private String getMessage() {
		
		return null;
	}

	private double getBMI() {
		
		return 0;
	}

	public static void main (String[] args) {
		launch(args);
	}
}