
import java.util.Scanner;

public class BMICalculator {
    private float weight; 
    private float height; 

   
    public BMICalculator() {
        this.weight = 0;
        this.height = 0;
    }

    
    public void setWeight(float weight) {
        this.weight = weight;
    }

    
    public void setHeight(float height) {
        this.height = height;
    }

    
    public float calculateBMI() {
        if (height <= 0) return 0;
        return weight / (height * height);
    }

   
    public String getBmiReport(float bmi) {
        if (bmi < 18.5) return "Underweight";
        else if (bmi >= 18.5 && bmi <= 24.9) return "Normal weight";
        else if (bmi >= 25 && bmi <= 29.9) return "Overweight";
        else return "Obese";
    }

    public static void main(String[] args) {
        BMICalculator bmiCalculator = new BMICalculator();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter weight in kg: ");
        float weight = scanner.nextFloat();
        bmiCalculator.setWeight(weight);

        System.out.print("Enter height in meters: ");
        float height = scanner.nextFloat();
        bmiCalculator.setHeight(height);

        float bmi = bmiCalculator.calculateBMI();
        System.out.println("Your BMI is: " + bmi);
        System.out.println("BMI Category: " + bmiCalculator.getBmiReport(bmi));
    }
}